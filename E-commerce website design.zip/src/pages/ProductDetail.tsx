import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { ShoppingCart, Heart, Star, Truck, Shield, RotateCcw, ChevronDown, ThumbsUp } from 'lucide-react';
import { products, reviews as mockReviews } from '../data/mockData';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { ProductCard } from '../components/ProductCard';
import { motion } from 'motion/react';
import { toast } from 'sonner@2.0.3';

export function ProductDetail() {
  const { id } = useParams();
  const product = products.find(p => p.id === id);
  const { addToCart } = useCart();
  const { addToWishlist, removeFromWishlist, isInWishlist } = useWishlist();

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(product?.colors?.[0]);
  const [selectedSize, setSelectedSize] = useState(product?.sizes?.[0]);
  const [expandedSection, setExpandedSection] = useState<string | null>('description');

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Product not found</h1>
          <Link to="/products" className="text-blue-600 hover:text-blue-700">
            Browse all products
          </Link>
        </div>
      </div>
    );
  }

  const images = product.images || [product.image];
  const productReviews = mockReviews.filter(r => r.productId === product.id);
  const inWishlist = isInWishlist(product.id);

  const relatedProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      variant: `${selectedColor || ''} ${selectedSize || ''}`.trim(),
      color: selectedColor,
      size: selectedSize,
    });
    toast.success('Added to cart!', {
      description: `${product.name} - ${selectedColor || ''} ${selectedSize || ''}`.trim(),
    });
  };

  const handleWishlist = () => {
    if (inWishlist) {
      removeFromWishlist(product.id);
      toast.info('Removed from wishlist');
    } else {
      addToWishlist({
        id: product.id,
        name: product.name,
        price: product.price,
        image: product.image,
        rating: product.rating,
        reviews: product.reviews,
      });
      toast.success('Added to wishlist!');
    }
  };

  const ratingBreakdown = [
    { stars: 5, count: 734, percentage: 59 },
    { stars: 4, count: 321, percentage: 26 },
    { stars: 3, count: 123, percentage: 10 },
    { stars: 2, count: 37, percentage: 3 },
    { stars: 1, count: 19, percentage: 2 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center space-x-2 text-sm text-gray-600 mb-6">
          <Link to="/" className="hover:text-blue-600">Home</Link>
          <span>/</span>
          <Link to="/products" className="hover:text-blue-600">Products</Link>
          <span>/</span>
          <Link to={`/products?category=${product.category}`} className="hover:text-blue-600">
            {product.category}
          </Link>
          <span>/</span>
          <span className="text-gray-900">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Image Gallery */}
          <div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl shadow-sm overflow-hidden mb-4"
            >
              <img
                src={images[selectedImage]}
                alt={product.name}
                className="w-full h-96 md:h-[500px] object-cover"
              />
            </motion.div>
            <div className="grid grid-cols-4 gap-4">
              {images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={`relative rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImage === idx ? 'border-blue-600' : 'border-gray-200 hover:border-gray-300'
                  }`}
                >
                  <img src={img} alt={`${product.name} ${idx + 1}`} className="w-full h-24 object-cover" />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="bg-white rounded-2xl shadow-sm p-6 md:p-8 h-fit">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">{product.name}</h1>
                <p className="text-blue-600 font-medium mb-3">Brand: {product.brand}</p>
              </div>
              <button
                onClick={handleWishlist}
                className={`p-3 rounded-full transition-colors ${
                  inWishlist ? 'bg-red-50 text-red-500' : 'bg-gray-100 hover:bg-gray-200'
                }`}
              >
                <Heart className={`w-6 h-6 ${inWishlist ? 'fill-current' : ''}`} />
              </button>
            </div>

            {/* Rating */}
            <div className="flex items-center space-x-4 mb-6 pb-6 border-b border-gray-200">
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(product.rating)
                          ? 'fill-yellow-400 text-yellow-400'
                          : 'text-gray-300'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg font-semibold">{product.rating}</span>
              </div>
              <span className="text-gray-600">
                {product.reviews.toLocaleString()} reviews
              </span>
            </div>

            {/* Price */}
            <div className="mb-6">
              <div className="flex items-baseline space-x-3 mb-2">
                <span className="text-4xl font-bold text-gray-900">${product.price}</span>
                {product.originalPrice && (
                  <>
                    <span className="text-xl text-gray-500 line-through">${product.originalPrice}</span>
                    <span className="px-3 py-1 bg-red-100 text-red-600 rounded-lg font-semibold">
                      {product.discount}% OFF
                    </span>
                  </>
                )}
              </div>
              <p className="text-sm text-gray-600">Inclusive of all taxes</p>
            </div>

            {/* Color Selection */}
            {product.colors && product.colors.length > 0 && (
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Color: {selectedColor}</h3>
                <div className="flex flex-wrap gap-3">
                  {product.colors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setSelectedColor(color)}
                      className={`px-4 py-2 border-2 rounded-lg transition-all ${
                        selectedColor === color
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      {color}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Size Selection */}
            {product.sizes && product.sizes.length > 0 && (
              <div className="mb-6">
                <h3 className="font-semibold mb-3">Size: {selectedSize}</h3>
                <div className="flex flex-wrap gap-3">
                  {product.sizes.map((size) => (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`px-4 py-2 border-2 rounded-lg transition-all ${
                        selectedSize === size
                          ? 'border-blue-600 bg-blue-50'
                          : 'border-gray-300 hover:border-gray-400'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Quantity</h3>
              <div className="flex items-center space-x-4">
                <div className="flex items-center border-2 border-gray-300 rounded-lg">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-4 py-2 hover:bg-gray-100"
                  >
                    -
                  </button>
                  <span className="px-6 py-2 font-semibold">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-4 py-2 hover:bg-gray-100"
                  >
                    +
                  </button>
                </div>
                <span className={`text-sm ${product.inStock ? 'text-green-600' : 'text-red-600'}`}>
                  {product.inStock ? 'In Stock' : 'Out of Stock'}
                </span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3 mb-6">
              <button
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="w-full py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center justify-center space-x-2"
              >
                <ShoppingCart className="w-5 h-5" />
                <span>Add to Cart</span>
              </button>
              <button
                disabled={!product.inStock}
                className="w-full py-4 bg-orange-600 text-white rounded-lg font-semibold hover:bg-orange-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
              >
                Buy Now
              </button>
            </div>

            {/* Delivery Info */}
            {product.deliveryDate && (
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
                <div className="flex items-center space-x-2 text-green-700">
                  <Truck className="w-5 h-5" />
                  <span className="font-semibold">Delivery by {product.deliveryDate}</span>
                </div>
              </div>
            )}

            {/* Features */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-gray-200">
              <div className="text-center">
                <Truck className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                <p className="text-xs text-gray-600">Free Delivery</p>
              </div>
              <div className="text-center">
                <RotateCcw className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                <p className="text-xs text-gray-600">30-Day Returns</p>
              </div>
              <div className="text-center">
                <Shield className="w-6 h-6 mx-auto mb-2 text-blue-600" />
                <p className="text-xs text-gray-600">2-Year Warranty</p>
              </div>
            </div>
          </div>
        </div>

        {/* Product Details Sections */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-12">
          {/* Description */}
          <div className="border-b border-gray-200">
            <button
              onClick={() => setExpandedSection(expandedSection === 'description' ? null : 'description')}
              className="w-full flex items-center justify-between py-4"
            >
              <h2 className="text-xl font-bold">Product Description</h2>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  expandedSection === 'description' ? 'rotate-180' : ''
                }`}
              />
            </button>
            {expandedSection === 'description' && (
              <div className="pb-6">
                <p className="text-gray-600 leading-relaxed">{product.description}</p>
              </div>
            )}
          </div>

          {/* Specifications */}
          {product.specifications && (
            <div className="border-b border-gray-200">
              <button
                onClick={() => setExpandedSection(expandedSection === 'specs' ? null : 'specs')}
                className="w-full flex items-center justify-between py-4"
              >
                <h2 className="text-xl font-bold">Specifications</h2>
                <ChevronDown
                  className={`w-5 h-5 transition-transform ${
                    expandedSection === 'specs' ? 'rotate-180' : ''
                  }`}
                />
              </button>
              {expandedSection === 'specs' && (
                <div className="pb-6">
                  <table className="w-full">
                    <tbody>
                      {Object.entries(product.specifications).map(([key, value], idx) => (
                        <tr key={idx} className={idx % 2 === 0 ? 'bg-gray-50' : ''}>
                          <td className="px-4 py-3 font-semibold text-gray-700">{key}</td>
                          <td className="px-4 py-3 text-gray-600">{value}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Warranty */}
          <div>
            <button
              onClick={() => setExpandedSection(expandedSection === 'warranty' ? null : 'warranty')}
              className="w-full flex items-center justify-between py-4"
            >
              <h2 className="text-xl font-bold">Warranty & Returns</h2>
              <ChevronDown
                className={`w-5 h-5 transition-transform ${
                  expandedSection === 'warranty' ? 'rotate-180' : ''
                }`}
              />
            </button>
            {expandedSection === 'warranty' && (
              <div className="pb-6 space-y-4">
                <div>
                  <h3 className="font-semibold mb-2">2-Year Warranty</h3>
                  <p className="text-gray-600">
                    This product comes with a 2-year manufacturer warranty covering defects in materials and
                    workmanship.
                  </p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">30-Day Returns</h3>
                  <p className="text-gray-600">
                    Not satisfied? Return within 30 days for a full refund. Product must be in original
                    condition with all accessories.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Customer Reviews */}
        <div className="bg-white rounded-2xl shadow-sm p-6 mb-12">
          <h2 className="text-2xl font-bold mb-6">Customer Reviews</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Rating Summary */}
            <div className="text-center">
              <div className="text-5xl font-bold mb-2">{product.rating}</div>
              <div className="flex items-center justify-center mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(product.rating)
                        ? 'fill-yellow-400 text-yellow-400'
                        : 'text-gray-300'
                    }`}
                  />
                ))}
              </div>
              <p className="text-gray-600">{product.reviews.toLocaleString()} reviews</p>
            </div>

            {/* Rating Breakdown */}
            <div className="md:col-span-2">
              {ratingBreakdown.map((item) => (
                <div key={item.stars} className="flex items-center space-x-3 mb-2">
                  <span className="text-sm w-12">{item.stars} star</span>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-yellow-400 h-2 rounded-full"
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                  <span className="text-sm text-gray-600 w-16">{item.percentage}%</span>
                </div>
              ))}
            </div>
          </div>

          {/* Reviews List */}
          <div className="space-y-6">
            {productReviews.map((review) => (
              <div key={review.id} className="border-b border-gray-200 pb-6 last:border-0">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center space-x-2 mb-1">
                      <span className="font-semibold">{review.userName}</span>
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < review.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-gray-600">{review.date}</p>
                  </div>
                </div>
                <h4 className="font-semibold mb-2">{review.title}</h4>
                <p className="text-gray-600 mb-3">{review.comment}</p>
                <button className="flex items-center space-x-2 text-sm text-gray-600 hover:text-blue-600">
                  <ThumbsUp className="w-4 h-4" />
                  <span>Helpful ({review.helpful})</span>
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div>
            <h2 className="text-2xl font-bold mb-6">Related Products</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {relatedProducts.map((relatedProduct) => (
                <ProductCard key={relatedProduct.id} product={relatedProduct} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}