import { Link, useParams } from 'react-router';
import { CheckCircle, Package, Home, FileText } from 'lucide-react';
import { motion } from 'motion/react';

export function OrderConfirmation() {
  const { id } = useParams();

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-2xl w-full"
      >
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12 text-center">
          {/* Success Icon */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', stiffness: 200 }}
            className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <CheckCircle className="w-16 h-16 text-green-600" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Order Placed Successfully!
            </h1>
            <p className="text-lg text-gray-600 mb-8">
              Thank you for your purchase. Your order has been confirmed.
            </p>

            {/* Order Details */}
            <div className="bg-gray-50 rounded-xl p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Order Number</p>
                  <p className="font-semibold text-lg">{id}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-600 mb-1">Estimated Delivery</p>
                  <p className="font-semibold text-lg">Feb 18-20, 2026</p>
                </div>
              </div>
            </div>

            {/* Confirmation Message */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-8">
              <p className="text-blue-800 text-sm">
                📧 A confirmation email has been sent to your registered email address with order details and tracking information.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Link
                to={`/orders/${id}`}
                className="flex flex-col items-center justify-center p-6 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
              >
                <Package className="w-8 h-8 mb-2" />
                <span className="font-semibold">Track Order</span>
              </Link>
              <Link
                to="/"
                className="flex flex-col items-center justify-center p-6 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition-colors"
              >
                <Home className="w-8 h-8 mb-2" />
                <span className="font-semibold">Continue Shopping</span>
              </Link>
              <button className="flex flex-col items-center justify-center p-6 border-2 border-gray-300 rounded-xl hover:bg-gray-50 transition-colors">
                <FileText className="w-8 h-8 mb-2" />
                <span className="font-semibold">Download Invoice</span>
              </button>
            </div>

            {/* Additional Info */}
            <div className="mt-8 pt-8 border-t border-gray-200">
              <p className="text-sm text-gray-600">
                Need help? Contact our{' '}
                <a href="#" className="text-blue-600 hover:text-blue-700 font-semibold">
                  customer support
                </a>
              </p>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
