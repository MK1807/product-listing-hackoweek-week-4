import { useState } from 'react';
import { useParams, Link } from 'react-router';
import { Package, Truck, CheckCircle, Download, RotateCcw } from 'lucide-react';
import { motion } from 'motion/react';

interface Order {
  id: string;
  date: string;
  status: 'processing' | 'shipped' | 'delivered';
  total: number;
  items: Array<{
    id: string;
    name: string;
    image: string;
    price: number;
    quantity: number;
  }>;
  tracking?: string;
  deliveryDate?: string;
}

const mockOrders: Order[] = [
  {
    id: 'ORD1707821234567',
    date: '2026-02-10',
    status: 'delivered',
    total: 549.98,
    deliveryDate: '2026-02-12',
    tracking: 'TRK123456789',
    items: [
      {
        id: '1',
        name: 'Premium Wireless Headphones - Noise Cancelling',
        image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=200&h=200&fit=crop',
        price: 299.99,
        quantity: 1,
      },
      {
        id: '2',
        name: 'Smart Watch Pro - Fitness & Health Tracker',
        image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=200&h=200&fit=crop',
        price: 249.99,
        quantity: 1,
      },
    ],
  },
  {
    id: 'ORD1707721234568',
    date: '2026-02-08',
    status: 'shipped',
    total: 119.99,
    tracking: 'TRK987654321',
    items: [
      {
        id: '5',
        name: 'Running Shoes - Performance Series',
        image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=200&h=200&fit=crop',
        price: 119.99,
        quantity: 1,
      },
    ],
  },
  {
    id: 'ORD1707621234569',
    date: '2026-02-06',
    status: 'processing',
    total: 89.99,
    items: [
      {
        id: '4',
        name: 'Designer Leather Backpack',
        image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=200&h=200&fit=crop',
        price: 89.99,
        quantity: 1,
      },
    ],
  },
];

export function Orders() {
  const { id } = useParams();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(
    id ? mockOrders.find(o => o.id === id) || null : null
  );

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'processing':
        return 'bg-yellow-100 text-yellow-700';
      case 'shipped':
        return 'bg-blue-100 text-blue-700';
      case 'delivered':
        return 'bg-green-100 text-green-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  const getStatusIcon = (status: Order['status']) => {
    switch (status) {
      case 'processing':
        return Package;
      case 'shipped':
        return Truck;
      case 'delivered':
        return CheckCircle;
      default:
        return Package;
    }
  };

  if (selectedOrder) {
    const StatusIcon = getStatusIcon(selectedOrder.status);
    
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <button
            onClick={() => setSelectedOrder(null)}
            className="text-blue-600 hover:text-blue-700 mb-6"
          >
            ← Back to Orders
          </button>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl shadow-sm p-6 md:p-8"
          >
            <div className="flex items-start justify-between mb-6">
              <div>
                <h1 className="text-2xl font-bold mb-2">Order #{selectedOrder.id}</h1>
                <p className="text-gray-600">Placed on {new Date(selectedOrder.date).toLocaleDateString()}</p>
              </div>
              <span className={`px-4 py-2 rounded-lg font-semibold capitalize ${getStatusColor(selectedOrder.status)}`}>
                {selectedOrder.status}
              </span>
            </div>

            {/* Order Timeline */}
            <div className="mb-8">
              <h2 className="font-bold mb-4">Order Status</h2>
              <div className="relative">
                <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200" />
                {[
                  { status: 'processing', label: 'Order Placed', date: selectedOrder.date },
                  { status: 'shipped', label: 'Shipped', date: selectedOrder.status !== 'processing' ? selectedOrder.date : undefined },
                  { status: 'delivered', label: 'Delivered', date: selectedOrder.deliveryDate },
                ].map((step, index) => {
                  const StepIcon = getStatusIcon(step.status as Order['status']);
                  const isCompleted = selectedOrder.status === 'delivered' || 
                    (selectedOrder.status === 'shipped' && step.status !== 'delivered') ||
                    step.status === 'processing';
                  
                  return (
                    <div key={step.status} className="relative flex items-center mb-6 last:mb-0">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                        isCompleted ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-400'
                      }`}>
                        <StepIcon className="w-4 h-4" />
                      </div>
                      <div className="ml-4">
                        <p className={`font-semibold ${isCompleted ? 'text-gray-900' : 'text-gray-400'}`}>
                          {step.label}
                        </p>
                        {step.date && (
                          <p className="text-sm text-gray-600">
                            {new Date(step.date).toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Tracking */}
            {selectedOrder.tracking && (
              <div className="mb-8 p-4 bg-blue-50 rounded-lg">
                <p className="text-sm text-gray-600 mb-1">Tracking Number</p>
                <p className="font-semibold text-lg">{selectedOrder.tracking}</p>
              </div>
            )}

            {/* Items */}
            <div className="mb-8">
              <h2 className="font-bold mb-4">Order Items</h2>
              <div className="space-y-4">
                {selectedOrder.items.map((item) => (
                  <div key={item.id} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <img src={item.image} alt={item.name} className="w-20 h-20 object-cover rounded" />
                    <div className="flex-1">
                      <h3 className="font-medium mb-1">{item.name}</h3>
                      <p className="text-sm text-gray-600">Quantity: {item.quantity}</p>
                    </div>
                    <p className="font-bold">${item.price.toFixed(2)}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Total */}
            <div className="border-t border-gray-200 pt-6">
              <div className="flex items-center justify-between text-xl font-bold">
                <span>Total</span>
                <span>${selectedOrder.total.toFixed(2)}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-8 flex flex-wrap gap-4">
              <button className="flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Download className="w-5 h-5" />
                <span>Download Invoice</span>
              </button>
              {selectedOrder.status === 'delivered' && (
                <button className="flex items-center space-x-2 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                  <RotateCcw className="w-5 h-5" />
                  <span>Return Order</span>
                </button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-bold mb-8">My Orders</h1>

        {mockOrders.length === 0 ? (
          <div className="bg-white rounded-xl shadow-sm p-12 text-center">
            <Package className="w-24 h-24 mx-auto mb-6 text-gray-300" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">No orders yet</h2>
            <p className="text-gray-600 mb-8">Start shopping to see your orders here.</p>
            <Link
              to="/products"
              className="inline-block px-8 py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              Start Shopping
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {mockOrders.map((order, index) => {
              const StatusIcon = getStatusIcon(order.status);
              
              return (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="bg-white rounded-xl shadow-sm overflow-hidden hover:shadow-lg transition-shadow"
                >
                  <div className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h3 className="font-bold text-lg mb-1">Order #{order.id}</h3>
                        <p className="text-sm text-gray-600">
                          {new Date(order.date).toLocaleDateString()} • {order.items.length} item(s)
                        </p>
                      </div>
                      <span className={`px-4 py-2 rounded-lg font-semibold capitalize flex items-center space-x-2 ${getStatusColor(order.status)}`}>
                        <StatusIcon className="w-4 h-4" />
                        <span>{order.status}</span>
                      </span>
                    </div>

                    <div className="flex items-center space-x-4 mb-4">
                      {order.items.slice(0, 3).map((item) => (
                        <img
                          key={item.id}
                          src={item.image}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded"
                        />
                      ))}
                      {order.items.length > 3 && (
                        <div className="w-16 h-16 bg-gray-100 rounded flex items-center justify-center text-gray-600 font-semibold">
                          +{order.items.length - 3}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t border-gray-200">
                      <p className="text-lg font-bold">Total: ${order.total.toFixed(2)}</p>
                      <button
                        onClick={() => setSelectedOrder(order)}
                        className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
