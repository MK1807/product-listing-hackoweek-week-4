import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { products, categories } from '../data/mockData';
import { ProductCard } from '../components/ProductCard';
import { motion } from 'motion/react';

const heroBanners = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1707486857191-0ec8e78f7118?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzaG9wcGluZyUyMHNhbGUlMjBiYW5uZXIlMjBjb2xvcmZ1bHxlbnwxfHx8fDE3NzA4NjkwMDJ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    title: 'Winter Sale',
    subtitle: 'Up to 60% off on selected items',
    cta: 'Shop Now',
    link: '/products?badge=deals',
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1758874385215-c86fe62b446f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvbmxpbmUlMjBzaG9wcGluZyUyMG1vZGVybiUyMGxhcHRvcHxlbnwxfHx8fDE3NzA4NzU2MDB8MA&ixlib=rb-4.1.0&q=80&w=1080',
    title: 'New Electronics',
    subtitle: 'Discover the latest tech gadgets',
    cta: 'Explore',
    link: '/products?category=electronics',
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1743877428895-fd3aabd06528?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmYXNoaW9uJTIwZGVhbHMlMjBjbG90aGluZyUyMHN0b3JlfGVufDF8fHx8MTc3MDg3NTYwMHww&ixlib=rb-4.1.0&q=80&w=1080',
    title: 'Fashion Forward',
    subtitle: 'Trending styles for the season',
    cta: 'Shop Fashion',
    link: '/products?category=fashion',
  },
];

export function Home() {
  const [currentBanner, setCurrentBanner] = useState(0);
  const [flashSaleTime, setFlashSaleTime] = useState({
    hours: 5,
    minutes: 23,
    seconds: 45,
  });

  useEffect(() => {
    const bannerInterval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % heroBanners.length);
    }, 5000);

    return () => clearInterval(bannerInterval);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setFlashSaleTime((prev) => {
        let { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else if (minutes > 0) {
          minutes--;
          seconds = 59;
        } else if (hours > 0) {
          hours--;
          minutes = 59;
          seconds = 59;
        }
        
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % heroBanners.length);
  };

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev - 1 + heroBanners.length) % heroBanners.length);
  };

  const bestSellers = products.filter(p => p.badges?.includes('Best Seller')).slice(0, 4);
  const newArrivals = products.filter(p => p.badges?.includes('New Arrival')).slice(0, 4);
  const flashDeals = products.filter(p => p.discount && p.discount >= 25).slice(0, 4);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Banner */}
      <div className="relative h-[500px] bg-gray-900 overflow-hidden">
        {heroBanners.map((banner, index) => (
          <motion.div
            key={banner.id}
            initial={false}
            animate={{
              opacity: index === currentBanner ? 1 : 0,
              scale: index === currentBanner ? 1 : 1.1,
            }}
            transition={{ duration: 0.7 }}
            className="absolute inset-0"
          >
            <img
              src={banner.image}
              alt={banner.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
                <motion.div
                  initial={{ opacity: 0, x: -50 }}
                  animate={{
                    opacity: index === currentBanner ? 1 : 0,
                    x: index === currentBanner ? 0 : -50,
                  }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="text-white max-w-xl"
                >
                  <h1 className="text-5xl md:text-6xl font-bold mb-4">{banner.title}</h1>
                  <p className="text-xl md:text-2xl mb-8">{banner.subtitle}</p>
                  <Link
                    to={banner.link}
                    className="inline-block px-8 py-4 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                  >
                    {banner.cta}
                  </Link>
                </motion.div>
              </div>
            </div>
          </motion.div>
        ))}

        {/* Navigation Buttons */}
        <button
          onClick={prevBanner}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-3 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors"
        >
          <ChevronLeft className="w-6 h-6 text-white" />
        </button>
        <button
          onClick={nextBanner}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-3 bg-white/20 backdrop-blur-sm rounded-full hover:bg-white/30 transition-colors"
        >
          <ChevronRight className="w-6 h-6 text-white" />
        </button>

        {/* Indicators */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex space-x-2">
          {heroBanners.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentBanner(index)}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentBanner ? 'bg-white w-8' : 'bg-white/50'
              }`}
            />
          ))}
        </div>
      </div>

      {/* Featured Categories */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Shop by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/products?category=${category.id}`}
                className="flex flex-col items-center p-6 bg-gray-50 rounded-xl hover:bg-blue-50 hover:shadow-md transition-all group"
              >
                <span className="text-4xl mb-3 group-hover:scale-110 transition-transform">
                  {category.icon}
                </span>
                <span className="text-sm text-center font-medium text-gray-900">
                  {category.name}
                </span>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Flash Deals */}
      <section className="py-12 bg-gradient-to-r from-orange-500 to-red-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <div className="text-white">
              <h2 className="text-3xl font-bold mb-2">⚡ Flash Deals</h2>
              <p className="text-white/90">Limited time offers - Hurry up!</p>
            </div>
            <div className="flex items-center space-x-4 bg-white/20 backdrop-blur-sm rounded-lg px-6 py-3">
              <Clock className="w-6 h-6 text-white" />
              <div className="flex space-x-2 text-white font-bold text-2xl">
                <div className="text-center">
                  <div>{String(flashSaleTime.hours).padStart(2, '0')}</div>
                  <div className="text-xs font-normal">Hours</div>
                </div>
                <div>:</div>
                <div className="text-center">
                  <div>{String(flashSaleTime.minutes).padStart(2, '0')}</div>
                  <div className="text-xs font-normal">Mins</div>
                </div>
                <div>:</div>
                <div className="text-center">
                  <div>{String(flashSaleTime.seconds).padStart(2, '0')}</div>
                  <div className="text-xs font-normal">Secs</div>
                </div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {flashDeals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Best Sellers */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">🏆 Best Sellers</h2>
            <Link
              to="/products?badge=bestseller"
              className="text-blue-600 hover:text-blue-700 font-medium flex items-center space-x-1"
            >
              <span>View All</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {bestSellers.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* New Arrivals */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">✨ New Arrivals</h2>
            <Link
              to="/products?badge=new"
              className="text-blue-600 hover:text-blue-700 font-medium flex items-center space-x-1"
            >
              <span>View All</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {newArrivals.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Promotional Banners */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="relative h-64 rounded-2xl overflow-hidden group">
              <img
                src="https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=800&h=400&fit=crop"
                alt="Electronics Sale"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-transparent flex items-center">
                <div className="p-8 text-white">
                  <h3 className="text-2xl font-bold mb-2">Electronics Sale</h3>
                  <p className="mb-4">Up to 40% off on gadgets</p>
                  <Link
                    to="/products?category=electronics"
                    className="inline-block px-6 py-2 bg-white text-blue-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                  >
                    Shop Now
                  </Link>
                </div>
              </div>
            </div>

            <div className="relative h-64 rounded-2xl overflow-hidden group">
              <img
                src="https://images.unsplash.com/photo-1445205170230-053b83016050?w=800&h=400&fit=crop"
                alt="Fashion Collection"
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-purple-900/80 to-transparent flex items-center">
                <div className="p-8 text-white">
                  <h3 className="text-2xl font-bold mb-2">Fashion Collection</h3>
                  <p className="mb-4">New trends just arrived</p>
                  <Link
                    to="/products?category=fashion"
                    className="inline-block px-6 py-2 bg-white text-purple-600 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                  >
                    Explore
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
