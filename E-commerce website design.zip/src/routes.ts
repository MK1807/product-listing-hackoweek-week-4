import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { ProductListing } from "./pages/ProductListing";
import { ProductDetail } from "./pages/ProductDetail";
import { Cart } from "./pages/Cart";
import { Checkout } from "./pages/Checkout";
import { Profile } from "./pages/Profile";
import { Wishlist } from "./pages/Wishlist";
import { Orders } from "./pages/Orders";
import { Login } from "./pages/Login";
import { Signup } from "./pages/Signup";
import { OrderConfirmation } from "./pages/OrderConfirmation";
import { Layout } from "./components/Layout";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "products", Component: ProductListing },
      { path: "products/:id", Component: ProductDetail },
      { path: "cart", Component: Cart },
      { path: "checkout", Component: Checkout },
      { path: "profile", Component: Profile },
      { path: "wishlist", Component: Wishlist },
      { path: "orders", Component: Orders },
      { path: "orders/:id", Component: Orders },
      { path: "login", Component: Login },
      { path: "signup", Component: Signup },
      { path: "order-confirmation/:id", Component: OrderConfirmation },
    ],
  },
]);
